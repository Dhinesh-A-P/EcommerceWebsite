from django.db import models

# Create your models here.
class admin_login(models.Model):
	username=models.CharField(max_length=20)
	password=models.CharField(max_length=20)
	
	class Meta:
		db_table="admin"

class user_login(models.Model):
	email=models.CharField(max_length=50)
	username=models.CharField(max_length=20)
	password=models.CharField(max_length=20)
	phoneno=models.BigIntegerField()
	address=models.CharField(max_length=200)

	class Meta:
		db_table="user"

class seller_login(models.Model):
	email=models.CharField(max_length=50)
	username=models.CharField(max_length=20)
	password=models.CharField(max_length=20)
	phoneno=models.BigIntegerField()

	class Meta:
		db_table="seller"

class products(models.Model):
	email=models.CharField(max_length=50)
	proname=models.CharField(max_length=100)
	price=models.IntegerField()
	photo=models.FileField(max_length=500, upload_to='', blank=True, null=True )
	category=models.CharField(max_length=50)

	class Meta:
		db_table="product"		

class category(models.Model):
	category=models.CharField(max_length=50)
	photo=models.FileField(max_length=500, upload_to='', blank=True, null=True )

	class Meta:
		db_table="categories"		

class order(models.Model):
	user=models.ForeignKey(user_login,on_delete=models.CASCADE, related_name='fr_user_login_id',blank=True,null=True)
	product=models.ForeignKey(products,on_delete=models.CASCADE, related_name='fr_products_id',blank=True,null=True)
	status=models.CharField(max_length=50)

	class Meta:
		db_table="orders"		