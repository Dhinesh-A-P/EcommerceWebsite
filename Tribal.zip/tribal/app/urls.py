from django.contrib import admin
from django.urls import path,include
from app import views

urlpatterns = [
    path('',views.home),
    path('home',views.home),



    path('adminlogin',views.adminlogin),
    path('adminlogincheck',views.adminlogincheck),
    path('admin',views.admin),
    path('admin_home',views.admin),
    path('admin_people',views.admin_people),
    path('admin_seller',views.admin_seller),
    path('admin_user',views.admin_user),
    path('backtopeople',views.backtopeople),
    path('admin_product',views.admin_product),
    path('deleterecord_adminpro/<int:id>',views.deleteproduct_adminpro),
    path('deleterecord_adminseller/<int:id>',views.deleteproduct_adminseller),
    path('deleterecord_adminuser/<int:id>',views.deleteproduct_adminuser),
    path('admin_addcat',views.admin_addcat),
    path('insertcategory',views.insertcategory),
    path('admin_viewcat',views.admin_viewcat),
    path('deleterecord_category/<int:id>',views.deleteproduct_category),

    

    path('signup',views.signup),
    path('signup_seller',views.signup_seller),
    path('Validateemail/',views.Validateemail),
    path('insertuser/',views.insertuser),
    path('userlogincheck',views.Userlogincheck),
    path('aboutus',views.aboutus),
    path('logout',views.logout),
    path('Validateemail_admin/',views.Validateemail_admin),
    path('insertseller/',views.insertseller),



    path('user',views.user),
    path('aboutus_user',views.aboutus_user),
    path('use_profile',views.use_profile),
    path('edit_user/<int:id>',views.edit_user),
    path('update_user_profile/<int:id>',views.update_user_profile),
    path('place_order/<int:id>/<str:cat>',views.place_order),
    path('cat/<str:cat>',views.category_before),
    path('cate/<str:cat>',views.category1),
    path('user_order',views.user_order),




    path('seller',views.seller),
    path('add_product',views.add_product),
    path('view_product',views.view_product),
    path('view_orders',views.view_orders),
    path('insertproduct',views.insertproduct),
    path('back',views.back),
    path('modifyrecord/<int:id>',views.modifyproduct),
    path('updateproduct/<int:id>',views.updateproduct),
    path('deleterecord/<int:id>',views.deleteproduct),
    path('aboutus_seller',views.aboutus_seller),
    path('sel_profile',views.sel_profile),
    path('edit_seller/<int:id>',views.edit_seller),
    path('update_seller_profile/<int:id>',views.update_seller_profile),
]