from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse,HttpRequest
from django.contrib import messages
from app.models import *

from django.core import serializers
import json

# Create your views here.

def home(request):
	obj=category.objects.all()
	return render(request,'home.html',{'obj':obj})

def category_before(request,cat):
	res = products.objects.filter(category=cat)
	return render(request,'category_before.html',{'result':res})


#Admin-----------------------------------------------------------------------------------
def adminlogin(request):
	return render(request,'admin/adminlogin.html')

def adminlogincheck(request):
	if request.method == 'POST':
		uname = request.POST['uname']
		pwd = request.POST['password']
		
		if admin_login.objects.filter(username=uname,password=pwd).exists():
			return HttpResponseRedirect('admin')

		else:
			messages.info(request,"Invalid Login")
			return render(request, 'adminlogin.html')

def admin(request):
	return render(request,'admin/admin.html')

def admin_people(request):
	return render(request,'admin/admin_people.html')

def admin_seller(request):
	res = seller_login.objects.all()
	return render(request,'admin/admin_seller.html',{'result':res})

def admin_user(request):
	res = user_login.objects.all()
	return render(request,'admin/admin_user.html',{'result':res})

def backtopeople(request):
	return render(request,'admin/admin_people.html')

def admin_product(request):
	res = products.objects.all()
	return render(request,'admin/admin_product.html',{'result':res})

def deleteproduct_adminpro(request,id):
	result=products.objects.get(id=id)
	result.delete()
	return HttpResponseRedirect('/admin_product')

def deleteproduct_adminseller(request,id):
	result=seller_login.objects.get(id=id)
	result.delete()
	return HttpResponseRedirect('/admin_seller')

def deleteproduct_adminuser(request,id):
	result=user_login.objects.get(id=id)
	result.delete()
	return HttpResponseRedirect('/admin_user')

def admin_addcat(request):
	return render(request,'admin/admin_addcat.html')

def insertcategory(request):
	if request.method == 'POST':
		n = request.POST['catname']
		ph = request.FILES["catphoto"]

		cat=category()
		cat.category=n
		cat.photo=ph
		cat.save()
		res="Added"
		return render(request,'admin/admin_addcat.html',{'result':res})

def admin_viewcat(request):
	res = category.objects.all()
	return render(request,'admin/admin_viewcat.html',{'result':res})

def deleteproduct_category(request,id):
	result=category.objects.get(id=id)
	result.delete()
	return HttpResponseRedirect('/admin_viewcat')



#Sign up/in--------------------------------------------------------------------------------
def signup(request):
	return render(request,'login.html')

def Validateemail(request):
	em = request.GET.get('Email', None)
	print(em)
	data = {
	'is_present': user_login.objects.filter(email=em).exists()
	}
	print(data)
	return JsonResponse(data)

def Validateemail_admin(request):
	em = request.GET.get('Email', None)
	print(em)
	data = {
	'is_present': seller_login.objects.filter(email=em).exists()
	}
	print(data)
	return JsonResponse(data)

def is_ajax(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

def insertuser(request):
	if is_ajax and request.method == "POST":
		
		frm=request.POST
		r=request.POST["email"]

		Email = frm.get("email")
		Username = frm.get("username")
		Password=frm.get("pass")
		Phoneno=frm.get("phone")

		user=user_login()
		user.email=Email	
		user.username=Username
		user.password=Password
		user.phoneno=Phoneno
		user.save()
		res="Success"
		return JsonResponse({"data": res})

def insertseller(request):
	if is_ajax and request.method == "POST":
		
		frm=request.POST
		r=request.POST["email"]

		Email = frm.get("email")
		Username = frm.get("username")
		Password=frm.get("pass")
		Phoneno=frm.get("phone")

		user=seller_login()
		user.email=Email	
		user.username=Username
		user.password=Password
		user.phoneno=Phoneno
		user.save()
		res="Success"
		return JsonResponse({"data": res})

def Userlogincheck(request):
	print("test")
	if request.method == 'POST':
		e = request.POST['email']
		pas = request.POST['pass']

		if user_login.objects.filter(email=e,password=pas).exists():
			request.session['ses']=e
			return HttpResponseRedirect('user')


		if seller_login.objects.filter(email=e,password=pas).exists():
			request.session['ses']=e
			return HttpResponseRedirect('seller')

		else:
			return render(request, 'login.html')

def logout(request):
	del request.session['ses']
	return HttpResponseRedirect('home')

def aboutus(request):
	return render(request,'about_us.html')



#Seller-------------------------------------------------------------------------------------
def signup_seller(request):
	return render(request,'seller/signup_seller.html')

def seller(request):
	return render(request,'seller/home_s.html')

def aboutus_seller(request):
	return render(request,'seller/aboutus_seller.html')

def add_product(request):
	return render(request,'seller/add_product.html')

def view_product(request):
	n=request.session['ses']
	em = seller_login.objects.get(email=n)
	res=products.objects.filter(email=em)
	return render(request,'seller/view_product.html',{'result':res})

def view_orders(request):
	n=request.session['ses']
	user=seller_login.objects.get(email=n)
	product=products.objects.filter(email=user.id)
	o = order.objects.all()
	res=[]
	for o in o:
		for p in product:
			if o.product.id == p.id:
				res.append(o)
	print(res)


	return render(request,'seller/view_orders.html',{'o':res})

def sel_profile(request):
	n=request.session['ses']
	em = seller_login.objects.filter(email=n)
	return render(request,'seller/profile_seller.html',{'result':em})

def insertproduct(request):
	if request.method == 'POST':
		em1 = request.session['ses']
		em=seller_login.objects.get(email=em1)
		n = request.POST['proname']
		p = request.POST['price']
		c = request.POST['category']
		ph = request.FILES["photo"]

		pro=products()
		pro.email=em
		pro.proname=n
		pro.price=p
		pro.category=c
		pro.photo=ph
		pro.save()
		res="Product Added"
		return render(request,'seller/add_product.html',{'result':res})

def back(request):
	return render(request,'seller/home_s.html')

def modifyproduct(request,id):
	result=products.objects.get(id=id)
	return render(request,'seller/modify_product.html',{'res':result})

def updateproduct(request,id):
	if request.method == 'POST':
		n=request.session['ses']
		em = seller_login.objects.get(email=n)
		na = request.POST['proname']
		p = request.POST['price']
		c = request.POST['category']
		ph = request.FILES["photo"]

		pro=products.objects.get(id=id)
		pro.proname=na
		pro.price=p
		pro.category=c
		pro.photo=ph
		pro.save()
		res="Modified Successfully"
		return render(request,'seller/modify_product.html',{'result':res})

def deleteproduct(request,id):
	result=products.objects.get(id=id)
	result.delete()
	return HttpResponseRedirect('/view_product')

def edit_seller(request,id):
	result=seller_login.objects.get(id=id)
	return render(request,'seller/edit_proseller.html',{'res':result})

def update_seller_profile(request,id):
	if request.method == 'POST':
		n=request.session['ses']
		em = seller_login.objects.get(email=n)
		na = request.POST['username']
		pa = request.POST['pass']
		ph = request.POST['phone']

		sel = seller_login.objects.get(id=id)
		sel.username=na
		sel.password=pa
		sel.phoneno=ph
		sel.save()
		return HttpResponseRedirect('/sel_profile')


#User---------------------------------------------------------------------------------------
def user(request):
	obj=category.objects.all()
	return render(request,'user/home_u.html',{'obj':obj})

def aboutus_user(request):
	return render(request,'user/aboutus_user.html')

def use_profile(request):
	n=request.session['ses']
	em = user_login.objects.filter(email=n)
	return render(request,'user/profile_user.html',{'result':em})

def edit_user(request,id):
	result=user_login.objects.get(id=id)
	return render(request,'user/edit_prouser.html',{'res':result})

def update_user_profile(request,id):
	if request.method == 'POST':
		n=request.session['ses']
		em = user_login.objects.get(email=n)
		na = request.POST['username']
		pa = request.POST['pass']
		ph = request.POST['phone']

		sel = user_login.objects.get(id=id)
		sel.username=na
		sel.password=pa
		sel.phoneno=ph
		sel.save()
		return HttpResponseRedirect('/use_profile')

def category1(request,cat):
	res = products.objects.filter(category=cat)
	return render(request,'user/category.html',{'result':res})

def place_order(request,id,cat):
	if request.session.has_key("ses"):
		em1 = request.session['ses']
		user=user_login.objects.get(email=em1)
		proid = products.objects.get(id=id)
		o=order()
		o.user=user
		o.product=proid
		o.status=0
		o.save()
		messages.success(request,"Order Is Placed")
		return HttpResponseRedirect('/cate/%s'%cat)
	else:
		return render(request,'login.html')

def user_order(request):
	n=request.session['ses']
	user=user_login.objects.get(email=n)
	res = order.objects.filter(user=user)
	return render(request,'user/user_order.html',{'result':res})
